const unrar = require('node-unrar-js'); console.log(Object.keys(unrar));
